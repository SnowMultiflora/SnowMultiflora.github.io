package cn.sxt.zxw;

public class Constant {
	public static final int GameWidth=500;
	public static final int Gameheight=500;
}
