package cn.sxt.zxw;

import java.awt.Graphics;
import java.awt.Image;

public class Apple extends GameObject {
	double degree; // ����Ƕ�
    public boolean live = true;

	public Apple(Image img, double x, double y) {
		this.x = x;
		this.y = y;
		this.img = img;
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		speed = 4;
		degree = Math.random() * Math.PI * 2;
	}

	public  void   draw(Graphics  g){
	         
	        if(live) {
	        g.drawImage(img, (int)x,(int) y, null);
	         
	        //��������Ƕ�ȥ��
	        x += speed*Math.cos(degree);
	        y += speed*Math.sin(degree);
	         
	         
	        if(x<0||x>Constant.GameWidth-width){
	            degree  = Math.PI - degree;
	        }
	        if(y<30){
	            degree  = - degree;
	        }
	        }
	}
}
