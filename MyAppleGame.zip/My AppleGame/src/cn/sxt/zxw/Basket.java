package cn.sxt.zxw;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;

public class Basket extends GameObject{
	boolean left,right;
	boolean live=true;
	
	public void drawSelf(Graphics g) {
		if (live) {
			g.drawImage(img, (int)x, (int)y, null);
			if (left) {
				x-=speed;
			}
			if (right) {
				x+=speed;
			}
		}	
	}
	
	public Basket(Image img,double x,double y) {
		this.img=img;
		this.x=x;
		this.y=y;
		this.speed=6;
		this.height=img.getHeight(null);
		this.width=img.getWidth(null);
	}

	//���̰���
	public void addDirection(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_LEFT:
			left=true;
			break;
		case KeyEvent.VK_RIGHT:
			right=true;
			break;
		}
	}
	
	//����̧��
	public void minusDirection(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_LEFT:
			left=false;
			break;
		case KeyEvent.VK_RIGHT:
			right=false;
			break;
		}
	}
}
